<?php

$baseUrl = 'http://hexalitics.com/mjlob';
// $baseUrl = '//localhost/SHM_chat';
//$baseUrl = '//mentorlocator.codiantdev.com';
return array_merge([
    'apiVersion' => '1.0.0',
    'swaggerVersion' => '3.2.0',
    'host' => 'hexalitics.com/mjlob',
    //'host' => 'mentorlocator.codiantdev.com',
    'basePath' => '/api',
    'baseUrl' => $baseUrl
]);