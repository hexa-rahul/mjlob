<?php

return [
    'paths' => [
        "/getProducts" => [
            "post" => [
                "tags" => [
                    "product"
                ],
                "summary"     => "Product List",
                "description" => "Product List",
                "operationId" => "Product List",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "X-localization",
                        "in"   => "header",
                        "description" => "X-localization(ar/en)",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "api-key",
                        "in"   => "header",
                        "description" => "api-key",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "version",
                        "in"   => "header",
                        "description" => "version",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "Authorization",
                        "in"   => "header",
                        "description" => "Authorization",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    // [
                    //     "in" => "formData",
                    //     "name" => "page_no",
                    //     "description" => "page_no",
                    //     "required" => false,
                    //     "type" => 'string',
                    // ],
                    // [
                    //     "in" => "formData",
                    //     "name" => "no_of_product",
                    //     "description" => "no_of_product",
                    //     "required" => false,
                    //     "type" => 'string',
                    // ]

                ],
                "responses" => [
                ]
            ]
            
        ],
        "/likeUnliked" => [
            "post" => [
                "tags" => [
                    "product"
                ],
                "summary"     => "Like / Unlike Product",
                "description" => "Like / Unlike Product",
                "operationId" => "Like / Unlike Product",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "X-localization",
                        "in"   => "header",
                        "description" => "X-localization(ar/en)",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "api-key",
                        "in"   => "header",
                        "description" => "api-key",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "version",
                        "in"   => "header",
                        "description" => "version",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "Authorization",
                        "in"   => "header",
                        "description" => "Authorization",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in"          => "formData",
                        "name"        => "product_id",
                        "description" => "product_id",
                        "required"    => true,
                        "type"        => 'number',
                    ],

                ],
                "responses" => [
                ]
            ]
            
        ]
    ],
    'definitions' => [ ]
];
