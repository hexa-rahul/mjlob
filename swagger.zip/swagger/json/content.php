<?php

return [
    'paths' => [
        "/privacyPolicy" => [
            "post" => [
                "tags" => [
                    "content"
                ],
                "summary"     => "Privacy Policy",
                "description" => "Privacy Policy",
                "operationId" => "Privacy Policy",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "X-localization",
                        "in"   => "header",
                        "description" => "X-localization(ar/en)",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "api-key",
                        "in"   => "header",
                        "description" => "api-key",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "version",
                        "in"   => "header",
                        "description" => "version",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
               
                ],
                "responses" => [
                ]
            ],
            
        ],
         "/termsCondition" => [
            "post" => [
                "tags" => [
                    "content"
                ],
                "summary"     => "Terms and Conditions",
                "description" => "Terms and Conditions",
                "operationId" => "Terms and Conditions",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "X-localization",
                        "in"   => "header",
                        "description" => "X-localization(ar/en)",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "api-key",
                        "in"   => "header",
                        "description" => "api-key",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "version",
                        "in"   => "header",
                        "description" => "version",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
               
                ],
                "responses" => [
                ]
            ],
            
        ],
         "/aboutUs" => [
            "post" => [
                "tags" => [
                    "content"
                ],
                "summary"     => "Contact Us",
                "description" => "Contact US",
                "operationId" => "Contact US",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "X-localization",
                        "in"   => "header",
                        "description" => "X-localization(ar/en)",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "api-key",
                        "in"   => "header",
                        "description" => "api-key",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "name" => "version",
                        "in"   => "header",
                        "description" => "version",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
               
                ],
                "responses" => [
                ]
            ],
            
        ],
    ],
    'definitions' => [ ]
];
