<?php

return [
    'paths' => [
        
        "/signup" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "signup profile",
                "description" => "signup profile",
                "consumes" => [
                    "multipart/form-data"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    
                    [
                        "in" => "formData",
                        "name" => "name",
                        "description" => "Enter name",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "username",
                        "description" => "Enter username",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "email",
                        "description" => "Enter email id",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "country_code",
                        "description" => "Enter country code",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "mobile",
                        "description" => "Enter mobile",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "password",
                        "description" => "Enter password",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "confirm_password",
                        "description" => "Enter confrim password",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "location",
                        "description" => "location",
                        "required" => true,
                        "type" => 'string',
                    ],
                ],
                "responses" => [
                    "default" => [
                        "description" => "successful operation"
                    ]
                ]
            ]
        ],
        "/social-login" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "Login/signup with Social",
                "description" => "Login/signup with Social",
                "operationId" => "social-login",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "role should be mentor/user and type google/facebook",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/socialLogin"
                        ]
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/login" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "Login a user",
                "description" => "Login for User",
                "operationId" => "login",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "role will be mentor/user",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/login_user"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ]
        ],
        "/account-verification" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "account verification",
                "description" => "account verification",
                "operationId" => "account verification",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "formData",
                        "name" => "name",
                        "description" => "Full name",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "id_proof",
                        "description" => "Id proof",
                        "required" => true,
                        "type" => 'file',
                    ],
                    [
                        "in" => "formData",
                        "name" => "mobile_no",
                        "description" => "mobile number",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "message",
                        "description" => "message",
                        "required" => true,
                        "type" => 'string',
                    ]
                    
                ],
                "responses" => [
                ]
            ]
        ],
        "/verify-mobile-username" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "verify-mobile-username",
                "description" => "verify-mobile-username",
                "operationId" => "verify-mobile-username",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/verify_code_def"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ]
        ],
        "/forgot-password" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "forgot password",
                "description" => "forgot password",
                "operationId" => "forgot password",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/forgot_password"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ]
        ],
        "/reset-password" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "reset password",
                "description" => "reset password",
                "operationId" => "reset password",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/reset_password_def"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ]
        ],
        "/change-password" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "change password",
                "description" => "change password",
                "operationId" => "change password",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/change_password_def"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ]
        ],
          "/logout" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "Logout User",
                "description" => "",
                "consumes" => [
                    "application/json"
                ], "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                ],
                "responses" => [
                    "405" => [
                        "description" => "Invalid input"
                    ]
                ],
            ],
        ],
        "/get-user-detail" => [
            "get" => [
                "tags" => [
                    "account"
                ],
                "summary" => "User detail",
                "description" => "User detail",
                "consumes" => [
                    "application/json"
                ], "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                ],
                "responses" => [
                    "405" => [
                        "description" => "Invalid input"
                    ]
                ],
            ],
        ],
    ],
    'definitions' => [
        'login_user' => [
            'type' => "object",
            'properties' => [
                'mobile_no' => [
                    'type' => 'string'
                ],
                'password' => [
                    'type' => 'string'
                ],
                'device_id' => [
                    'type' => 'string'
                ],
                'device_type' => [
                    'type' => 'string'
                ],
                'certification_type' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "Login"
            ]
        ],
        'resend_code' => [
            'type' => "object",
            'properties' => [
                'email' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "resend_code"
            ]
        ],
        'check_verify_def' => [
            'type' => "object",
            'properties' => [
                'email' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "resend_code"
            ]
        ],
        'verify_code_def' => [
            'type' => "object",
            'properties' => [
                'value' => [
                    'type' => 'string'
                ],
                 'type' => [
                    'type' => 'string'
                ],
                
            ],
            'xml' => [
                'name' => "verify_code1"
            ]
        ],
        'forgot_password' => [
            'type' => "object",
            'properties' => [
                'email' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "forgot_password"
            ]
        ],
        'change_password_def'=>[
            'type' => "object",
            'properties' => [
                'current_password' => [
                    'type' => 'string'
                ],
                'new_password' => [
                    'type' => 'string'
                ],
                'confirm_password' => [
                    'type' => 'string'
                ]
              
            ],
            'xml' => [
                'name' => "change_password"
            ]
        ],
        'reset_password_def' => [
            'type' => "object",
            'properties' => [
                'mobile_no' => [
                    'type' => 'string'
                ],
                'password' => [
                    'type' => 'string'
                ]
              
            ],
            'xml' => [
                'name' => "reset_password"
            ]
        ],
         'socialLogin' => [
            'type' => "object",
            'properties' => [
                'type' => [
                    'type' => 'string',
                    'enum' => ['google','facebook','twitter']
                ],
                'first_name' => [
                    'type' => 'string'
                ],
                'last_name' => [
                    'type' => 'string'
                ],
                'email' => [
                    'type' => 'string'
                ],
                'profile_image' => [
                    'type' => 'string'
                ],
                'source_id' => [
                    'type' => 'string'
                ],
                'device_id' => [
                    'type' => 'string'
                ],
                'device_type' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "Login"
            ]
        ]
    ]
];
