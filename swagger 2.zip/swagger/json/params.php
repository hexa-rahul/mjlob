<?php
$baseUrl = '//localhost/SHM_chat';
//$baseUrl = '//mentorlocator.codiantdev.com';
return array_merge([
    'apiVersion' => '1.0.0',
    'swaggerVersion' => '3.2.0',
    'host' => 'localhost/SHM_chat',
    //'host' => 'mentorlocator.codiantdev.com',
    'basePath' => '/api',
    'baseUrl' => $baseUrl
]);