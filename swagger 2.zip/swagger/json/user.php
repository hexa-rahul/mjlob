<?php

return [
    'paths' => [
        "/account-verification" => [
            "post" => [
                "tags" => [
                    "user"
                ],
                "summary" => "account-verification",
                "description" => "account-verification",
                "operationId" => "post",
                "consumes" => [
                    "multipart/form-data"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "formData",
                        "name" => "full_name",
                        "description" => "full_name",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "mobile_no",
                        "description" => "mobile_no",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "message",
                        "description" => "message",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "id_proof",
                        "description" => "id_proof",
                        "required" => true,
                        "type" => 'file',
                    ]

                ],
                "responses" => [
                ]
            ],
        ],
        "/request-add" => [
            "post" => [
                "tags" => [
                    "user"
                ],
                "summary" => "request-add",
                "description" => "request-add",
                "operationId" => "post",
                "consumes" => [
                    "multipart/form-data"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "formData",
                        "name" => "mobile_no",
                        "description" => "mobile_no",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "user_id",
                        "description" => "user_id",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "add_name",
                        "description" => "add_name",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "add_detail",
                        "description" => "add_detail",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "company_id",
                        "description" => "company_id",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "position",
                        "description" => "position",
                        "required" => true,
                        "enum"=>['middle','top'],
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "website_link",
                        "description" => "website_link",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "add_picture",
                        "description" => "add_picture",
                        "required" => true,
                        "type" => 'file',
                    ]

                ],
                "responses" => [
                ]
            ],
        ],
        "/customer-care" => [
            "post" => [
                "tags" => [
                    "user"
                ],
                "summary" => "customer-care",
                "description" => "customer-care",
                "operationId" => "customer-care",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "customer-care",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/customer-def"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ],
        ],
        // "/services" => [
        //     "get" => [
        //         "tags" => [
        //             "user"
        //         ],
        //         "summary" => "service list",
        //         "description" => "service list",
        //         "operationId" => "service list",
        //         "consumes" => [
        //             "application/json"
        //         ],
        //         "produces" => [
        //             "application/json"
        //         ],
        //         "parameters" => [
        //             [
        //                 "name" => "access-token",
        //                 "in" => "header",
        //                 "description" => "Access Token",
        //                 "required" => true,
        //                 "type" => "string",
        //                 "format" => "int64"
        //             ],
        //             [
        //                 "name" => "catery_id",
        //                 "in" => "query",
        //                 "description" => "catery_id",
        //                 "required" => true,
        //                 "type" => "integer",
        //                 "format" => "int64"
        //             ],
        //             [
        //                 "in" => "query",
        //                 "name" => "mentor_id",
        //                 "description" => "mentor_id",
        //                 "required" => false,
        //                 "type" => "integer",
        //                 "format" => "int64"
        //             ]
        //         ],
        //         "responses" => [
        //         ]
        //     ],
        // ],
         
         
         
    ],
    'definitions' => [
        'customer-def' => [
            'type' => "object",
            'properties' => [
                'message' => [
                    'type' => 'string'
                ],
                'mobile_no' => [
                    'type' => 'string'
                ],
            ],
            'xml' => [
                'name' => "customer-care"
            ]
        ],
        'lat_long' => [
            'type' => "object",
            'properties' => [
                'latitude' => [
                    'type' => 'integer'
                ],
                'longitude' => [
                    'type' => 'integer'
                ],
            ],
            'xml' => [
                'name' => "appointment"
            ]
        ],
        'offer_update' => [
            'type' => "object",
            'properties' => [
                'offer_id' => [
                    'type' => 'integer'
                ],
                'status' => [
                    'type' => 'string'
                ],
               
            ],
            'xml' => [
                'name' => "appointment"
            ]
        ],
    ]
];
