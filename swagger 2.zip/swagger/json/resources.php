<?php

$params = require_once('params.php');
$account = require_once('account.php');
$user = require_once('user.php');


$paths = array_merge($account['paths'],$user['paths']);

$definitions = array_merge($account['definitions'],$user['definitions']);

echo json_encode([
    'tags' => [
        // [
        //     'name' => 'common',
        //     'description' => 'Common operation.',
        // ],
        [
            'name' => 'account',
            'description' => 'User account operations.',
        ]
        ,
        [
            'name' => 'user',
            'description' => 'Operation about user.',
        ],
        // [
        //     'name' => 'notification',
        //     'description' => 'Operation about Executive.',
        // ],
        // [
        //     'name' => 'chat',
        //     'description' => 'Operation about chat.',
        // ],
		// [
        //     'name' => 'transaction',
        //     'description' => 'Operation about transaction.',
        // ]
    ],
    "swagger" => "2.0",
    "info" => [
        "version" => "2.0.0",
        "title" => "SHM chat API"
    ],
    "host" => $params['host'],
    "basePath" => $params['basePath'],
    "schemes" => [
        "http",
        "https"
    ],
    'paths' => $paths,
    'definitions' => $definitions
]);
